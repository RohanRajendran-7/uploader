  function sendEmail() {
      Email.send({
        Host: "smtp.gmail.com",
        Username : "rohithrajendran09@gmail.com",
        Password : "nothingworthhavingcomeseasy",
        To : 'rohithrajendran09@gmail.com',
        From : "rohithrajendran09@gmail.com",
        Subject : "<email subject>",
        Body : "<email body>",
      })
      .then(function(message){
        alert("mail sent successfully")
      });
    }
